
import random

num=int(input("Dame el tamaño del vector: "))

V=[None]*num

for i in range(0,num):
 V[i]= random.randint(0,1)
 print (V[i])





n=int(input("número a buscar"))

r=int(int())
n1=V.count(n)


print()

print(f"el {n} se repite: {n1}")

